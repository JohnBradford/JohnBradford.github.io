curve(dnorm(x, mean=0, sd=1), 
      main="Two-Tailed Test, Z(Critical) = 1.96",
      xlim=c(-3, 3), ylim=c(0.025,0.4),
      xlab="z-scores", ylab="Density",
      add=F, lwd=2, col="blue", xaxt = "n")
axis(side=1, at=c(-1.96, 1.96))

#1.96 = 95%
cord.x <- c(-3,seq(-3,-1.96,0.01),-1.96)
cord.y <- c(-3,dnorm(seq(-3,-1.96,0.01)),0)
polygon(cord.x,cord.y,col="lightpink")

cord.x <- c(1.96,seq(1.96,3,0.01),3)
cord.y <- c(-1,dnorm(seq(1.96, 3, 0.01)),0)
polygon(cord.x,cord.y,col="lightpink")


#abline(v=0, col="red", lwd=3)
text(x=0, pos=3, y=0.15, cex=1.5, label="95% of total area")
arrows(x0=0, x1=1.96, y0=0.05, lwd=2)
arrows(x0=-0, x1=-1.96, y0=0.05, lwd=2)


