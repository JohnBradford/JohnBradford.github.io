#random Question
x <- round(rnorm(1)*100)/100
print(x)