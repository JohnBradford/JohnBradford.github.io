curve(dnorm(x, mean=0, sd=1), 
      main="One-Tailed Test for lower tail, Z(critical) = -1.65",
      xlim=c(-3, 3), ylim=c(0.025,0.4),
      xlab="z-scores", ylab="Density",
      add=F, lwd=2, col="blue", xaxt = "n")
axis(side=1, at=c(-1.65))

#1.65 = 95% one-tailed left
cord.x <- c(-3,seq(-3,-1.65,0.01),-1.65)
cord.y <- c(-3,dnorm(seq(-3,-1.65,0.01)),0)
polygon(cord.x,cord.y,col="lightpink")


#abline(v=0, col="red", lwd=3)
text(x=0, pos=3, y=0.15, cex=1.5, label="95% of total area")
arrows(x0=0, x1=-1.65, y0=0.05, lwd=2)
arrows(x0=-0, x1=2, y0=0.05, lwd=2)

