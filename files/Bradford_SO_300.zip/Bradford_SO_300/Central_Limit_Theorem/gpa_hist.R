clrs <- rainbow(5)
sds <- c(2, 4, 10, 20)
sAll <- replicate(10000, mean(sample(gpa, size=2)))
hist(sAll, freq=F,
     ylim=c(0,5), xlim=c(2, 4))
curve(dnorm(x, mean=mean(sAll), sd=sd(sAll)), add=T, 
      ylim=c(0,5), xlim=c(2, 4))


text(x=35, y=.15, label="Sampling Distribtions Taken from Different Sample Sizes (N)", cex=2)
j <- 1
for(i in sds) {
  sAll <- replicate(10000, mean(sample(gpa, size=i)))
 # hist(sAll, freq=F)
  curve(dnorm(x, mean=mean(sAll), 
              sd=sd(sAll)), add=T, 
        ylim=c(0,5), xlim=c(2, 4))
  j <- j + 1
  q <- qnorm(.5, sd=i)
  yp <- dnorm(q, sd=i)
  text(x=q, y=yp, label=paste("df=", i, sep=""))
}



hist(sAll, freq=F, xlim=c(2, 4))
