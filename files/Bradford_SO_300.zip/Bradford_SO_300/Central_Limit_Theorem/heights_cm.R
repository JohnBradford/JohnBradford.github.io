curve(dnorm(x, mean=mean(pop), 
            sd=sd(pop)), xlim=c(150,200),ylim=c(0,0.08),
      main="Distribution of Male Adult Heights in the US (cm)",
      xlab="Heights (cm)", ylab="density (probability per cm)",
      add=F, lwd=2, col="blue")
abline(v=mean(pop), col="red")
text(x=mean(pop), y=0.07, label=paste("mean=", round(100*mean(pop))/100, sep=""))