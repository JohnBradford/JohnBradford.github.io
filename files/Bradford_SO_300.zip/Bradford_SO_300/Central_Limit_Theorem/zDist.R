curve(dnorm(x, mean=0, sd=1), 
      main="Standard Normal Distribution (Z-Distribution)",
      xlim=c(-3.5, 3.5), ylim=c(0,0.4),
      xlab="z-scores", ylab="Density (Relative Likelihood)",
      add=F, lwd=2, col="blue")

cord.x <- c(-1,seq(-1,1,0.01),1)
cord.y <- c(-1,dnorm(seq(-1,1,0.01)),0)
polygon(cord.x,cord.y,col="lightcyan")

#1-2 standard deviations
cord.x <- c(-2,seq(-2,-1,0.01),-1)
cord.y <- c(-2,dnorm(seq(-2,-1,0.01)),0)
polygon(cord.x,cord.y,col="lightgoldenrod")

cord.x <- c(1,seq(1,2,0.01),2)
cord.y <- c(-1,dnorm(seq(1, 2, 0.01)),0)
polygon(cord.x,cord.y,col="lightgoldenrod")


#2-3 standard deviations
cord.x <- c(-3,seq(-3,-2,0.01),-2)
cord.y <- c(-3,dnorm(seq(-3,-2,0.01)),0)
polygon(cord.x,cord.y,col="lightgoldenrodyellow")

cord.x <- c(2,seq(2,3,0.01),3)
cord.y <- c(-1,dnorm(seq(2, 3, 0.01)),0)
polygon(cord.x,cord.y,col="lightgoldenrodyellow")

#Greater than 3 standard deviations
cord.x <- c(-4,seq(-4,-3,0.01),-3)
cord.y <- c(-4,dnorm(seq(-4,-3,0.01)),0)
polygon(cord.x,cord.y,col="lightpink")

cord.x <- c(3,seq(3,4,0.01),4)
cord.y <- c(-1,dnorm(seq(3, 4, 0.01)),0)
polygon(cord.x,cord.y,col="lightpink")

abline(v=0, col="red", lwd=3)
text(x=0.5, pos=3, y=0.25, cex=1, label="34.13%")
text(x=-0.5, pos=3, y=0.25, cex=1, label="34.13%")
#text(x=0, pos=3, y=0.4, cex=2.5, label="68.26%")

text(x=1.4, pos=3, y=0.055, cex=1, label="13.59%")
text(x=-1.4, pos=3, y=0.055, cex=1, label="13.59%")

text(x=2.55, pos=3, y=0.015, cex=1, label="2.15%")
text(x=-2.55, pos=3, y=0.015, cex=1, label="2.15%")

text(x=3.2, pos=3, y=0.001, cex=1, label=".13%")
text(x=-3.2, pos=3, y=0.001, cex=1, label=".13%")

