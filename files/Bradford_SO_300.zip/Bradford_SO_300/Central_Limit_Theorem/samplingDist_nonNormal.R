chid <- rchisq(n=100000, df=3)
m <- mean(chid)
plot(density(chid),
      main="Sampling Distributions from a Non-Normal Population", 
  xlab="values", lwd=3,
      ylim=c(0, 1.65),
      xlim=c(0, 10))
abline(v=m, lwd=2, col="red")
text(x=1, y=0.3, label="Population")
text(x=4, y=0.2, pos=4, cex=.9,
    label="Sampling Distributions of different\nsample sizes (N) from a Non-Normal Population")

N <- c(2, 10, 100)
clrs <- rainbow(3)
j <- 1
for(i in N){
  #h <- hist(pop, freq=FALSE, breaks=200)
  s <- replicate(10000, mean(sample(chid, size=N[j])))
  lines(density(s), col=clrs[j])
  
  q <- qnorm(.5, mean=mean(s), sd=sd(s))
  yp <- dnorm(q, mean=mean(s), sd=(sd(s)))
  text(x=mean(s), y=yp, label=paste("N=", i, sep=""))
  
  j <- j + 1
}
