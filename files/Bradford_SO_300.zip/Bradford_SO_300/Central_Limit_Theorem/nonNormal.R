#chid <- rchisq(n=100000, df=3)
m <- mean(chid)
plot(density(chid),
     main="Non-Normal Population", 
     xlab="values", lwd=3,
     ylim=c(0, .5),
     xlim=c(0, 10))
abline(v=m, lwd=2, col="red")
