curve(dnorm(x, mean=mean(pop), sd=sd(pop)), 
      main="Distribution of Male Adult Heights in the US (cm)",
      add=F, lwd=2, col="blue",  xlab="Heights (cm)", ylab="density (probability per cm)",
      ylim=c(0, .5),
      xlim=c(mean(pop) - 3*sd(pop), mean(pop)+ 3*sd(pop)))
abline(v=mean(pop), col="red")
text(x=mean(pop), y=.5, label=paste("mean =", round(100*mean(pop))/100, sep=""))
text(x=158, y=0.35, pos=4, cex=.9,
     label="Sampling Distributions of different\nsample sizes (N) from a Normal Population")
N <- c(2, 5, 10, 50)
clrs <- rainbow(4)
j <- 1
for(i in N){
  #h <- hist(pop, freq=FALSE, breaks=200)
  curve(dnorm(x, mean=mean(pop), sd=(sd(pop)/sqrt(N[j]))), 
        add=T, col=clrs[j],
        xlim=c(mean(pop) - 3*sd(pop), mean(pop)+ 3*sd(pop)))
  q <- qnorm(.5, mean=mean(pop), sd=(sd(pop)/sqrt(N[j])))
  yp <- dnorm(q, mean=mean(pop), sd=(sd(pop)/sqrt(N[j])))
  text(x=q, y=yp, label=paste("N=", i, sep=""))
  j <- j + 1
}
