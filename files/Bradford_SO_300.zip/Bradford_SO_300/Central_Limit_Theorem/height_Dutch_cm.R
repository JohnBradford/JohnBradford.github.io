curve(dnorm(x, mean=mean(pop), 
            sd=sd(pop)), xlim=c(150,200),ylim=c(0,0.08),
      main="Distribution of Male Adult Heights in the US (cm)",
      xlab="Heights (cm)", ylab="Density (Relative Likelihood)",
      add=F, lwd=2, col="blue")
abline(v=mean(pop), col="red")
abline(v=mean(sDutch20), col="green")
text(x=mean(pop), y=0.07, 
     label=paste("Overall American mean=", round(100*mean(pop))/100, sep=""))
text(x=mean(sDutch20), y=0.060, 
     label=paste("Dutch mean=", round(100*mean(sDutch20))/100, sep=""))
