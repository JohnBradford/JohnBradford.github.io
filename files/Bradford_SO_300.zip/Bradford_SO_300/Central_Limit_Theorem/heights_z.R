curve(dnorm(x, mean=mean(popz), sd=sd(popz)), 
      main="Distribution of Male Adult Heights in the US (z-scores)",
      xlim=c(mean(popz) - 3*sd(popz), mean(popz)+ 3*sd(popz)),
      xlab="Heights (z-scores)", ylab="% of population",
      add=F, lwd=2, col="blue")
abline(v=mean(popz), col="red")
text(x=-2.5, y=0.3, labels="Variance = 1")
text(x=-2.5, y=0.25, labels="Stnd Dev = 1")
text(x=mean(popz), y=0.18, label=paste("mean=", round(100*mean(popz))/100, sep=""))