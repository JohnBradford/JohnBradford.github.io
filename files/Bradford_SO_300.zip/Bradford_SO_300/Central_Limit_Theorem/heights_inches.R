curve(dnorm(x, mean=mean(pop2), sd=sd(pop2)), 
      main="Distribution of Male Adult Heights in the US (inches)",
      xlim=c(60,78),ylim=c(0,0.20),
      xlab="Heights (inches)", ylab="density (probability per inch)",
      add=F, lwd=2, col="blue")
abline(v=mean(pop2), col="red")
text(x=mean(pop2), y=0.18, label=paste("mean=", round(100*mean(pop2))/100, sep=""))