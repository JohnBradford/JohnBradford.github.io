# Code placed in this file fill be executed every time the
# lesson is started. Any variables created here will show up in
# the user's working directory and thus be accessible to them
# throughout the lesson.


#myRandomVariable <- round(rnorm(1)*100)/100
#set.seed(10)
pop <- rnorm(100000, mean=176.3, sd=6)
pop2 <- pop*0.393701  #convert to inches
popz <- scale(pop)
popDutch <- rnorm(100000, mean=183.2, sd=6)
sDutch20 <-  183
chid <- rchisq(n=100000, df=3)
sat <- read.table("http://www.stats4stem.org/uploads/1/7/6/7/1767713/sat.txt", header=TRUE)
  #sample(popDutch, size=20)