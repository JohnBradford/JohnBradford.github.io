curve(dnorm(x, mean=mean(popz), sd=sd(popz)), 
      main="Distribution of Male Adult Heights in the US (z-scores)",
      xlim=c(mean(popz) - 3*sd(popz), mean(popz)+ 3*sd(popz)),
      xlab="Heights (z-scores)", ylab="% of population",
      add=F, lwd=2, col="blue")
abline(v=mean(popz), col="red")
zD <- (mean(sDutch20) - mean(pop)) / sd(pop)
abline(v=zD, col="green")
text(x=mean(popz), y=0.18, label="Pop. Mean")
text(x=zD, y=0.3, pos=4, label="Dutch Mean (n=20)")
text(x=zD, y=0.26, pos=4, label=round(1000*zD)/1000)