cord.x <- c(-1,seq(-1,1,0.01),1)
cord.y <- c(-1,dnorm(seq(-1,1,0.01)),0)
curve(dnorm(x,0,1),xlim=c(-3,3),main='Standard Normal')
polygon(cord.x,cord.y,col='skyblue')

curve(dnorm(x, mean=mean(popz), sd=sd(popz)), 
      main="Distribution of Male Adult Heights in the US (z-scores)",
      xlim=c(mean(popz) - 3*sd(popz), mean(popz)+ 3*sd(popz)),
      xlab="Heights (z-scores)", ylab="Density (Relative Likelihood)",
      add=F, lwd=2, col="blue")
cord.x <- c(-1,seq(-1,1,0.01),1)
cord.y <- c(-1,dnorm(seq(-1,1,0.01)),0)
polygon(cord.x,cord.y,col='skyblue')
abline(v=mean(popz), col="red", lwd=3)
zD <- (mean(sDutch20) - mean(pop)) / sd(pop)
abline(v=zD, col="green", lwd=3)
text(x=0.5, pos=3, y=0.18, cex=1, label="34.13%\n0,+1")
text(x=-0.5, pos=3, y=0.18, cex=1, label="34.13%\n-1,0")
text(x=0, pos=3, y=0.25, cex=3, label="68.26%")
text(x=zD, y=0.3, pos=4, label="Dutch Mean (n=20)")
text(x=zD, y=0.26, pos=4, label=round(1000*zD)/1000)
