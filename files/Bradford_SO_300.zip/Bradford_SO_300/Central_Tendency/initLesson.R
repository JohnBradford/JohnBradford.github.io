# Code placed in this file fill be executed every time the
# lesson is started. Any variables created here will show up in
# the user's working directory and thus be accessible to them
# throughout the lesson.
sat <- read.table("http://www.stats4stem.org/uploads/1/7/6/7/1767713/sat.txt", header=TRUE)

#assign("sat", sat <- read.table("http://www.stats4stem.org/uploads/1/7/6/7/1767713/sat.txt", header=TRUE)openintro::cars, envir=globalenv())